# Kit documentaire ECOCERT SP3

Fichiers reconstitués depuis EXPLICATION-PLAYBOOKS.md le 9 novembre 2026.
Comparer aux fichiers du contrôleur avant utilisation : aucune récupération directe des VM.

Contrôleur SRVANSIBLE ; client pilote CLIENTANSIBLE, 172.16.53.151.
Adapter inventory.ini à la machine réelle. Préparer SSH par clé et sudo selon la procédure.
La collection ansible.posix est requise. Aucun secret ni clé privée ne figure dans ce kit.

Depuis ce dossier :

```bash
ansible-inventory --graph
ansible-playbook playbooks/00-controles.yml --syntax-check
ansible-playbook playbooks/00-controles.yml --limit CLIENTANSIBLE -K
```

Valider chaque playbook individuellement. site.yml regroupe 00, 01, 02 et 04.
Les playbooks 03 et 05 sont lancés séparément après préparation.
Conserver un instantané et un accès console avant modification de SSH et PAM.
Le prototype en VLAN 53 ne remplace pas la recette exigée dans le VLAN Formations.
